package com.novelplatform.novelsite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NovelsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(NovelsiteApplication.class, args);
	}

}
