package com.novelplatform.novelsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NovelsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
